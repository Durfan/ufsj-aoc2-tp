#include "./include/main.h"

void createFile(char *file) {
    FILE *fp = fopen(file, "w");
    assert(fp);
    fclose(fp);
}

void saveResult(float hit, float miss, char *file) {
    FILE *fp = fopen(file, "a");
    assert(fp);

    if ( config.bloco == 1 )
        fprintf(fp, "%d", config.words);

    fprintf(fp, " %05.2f %05.2f", hit, miss);

    if ( (config.words == config.bloco) || (config.bloco == 32) )
        fprintf(fp, "\n");

    fclose(fp);
}