#ifndef FILES_H
#define FILES_H

void createFile(char *file);
void saveResult(float hit, float miss, char *file);

#endif //FILES_H