#ifndef VALIDA_H
#define VALIDA_H

void valida();
void isSorted();
void debugSRTmem();
void debugPRTmem();

#endif //MAIN_H