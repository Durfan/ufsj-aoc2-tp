#ifndef SIMCACHE_GNUPLOT_H
#define SIMCACHE_GNUPLOT_H

void plot();

#endif //SIMCACHE_GNUPLOT_H