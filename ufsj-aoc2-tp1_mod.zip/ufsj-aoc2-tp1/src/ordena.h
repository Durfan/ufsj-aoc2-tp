#ifndef ORDENA_H
#define ORDENA_H

int  partition(cache_t *cache, int start, int end);
void quicksort(cache_t *cache, int start, int end);
void selection(cache_t *cache);
void bubbleSrt(cache_t *cache);

#endif //ORDENA_H