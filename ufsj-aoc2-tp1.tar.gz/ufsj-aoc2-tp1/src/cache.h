#ifndef SIMCACHE_CACHE_H
#define SIMCACHE_CACHE_H

int mod(int memAddr);
void initCache();
void pushCache(int memAddr);
void prtCache();

#endif //SIMCACHE_CACHE_H