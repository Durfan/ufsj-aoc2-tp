#ifndef SIMCACHE_TCOLORS_H
#define SIMCACHE_TCOLORS_H

#define cRED  "\x1b[31m"
#define cGREN "\x1b[32m"
#define cYELL "\x1b[33m"
#define cBLUE "\x1b[36m"
#define cGRAY "\x1b[90m"
#define bBLUE "\x1b[44m"
#define cRSET "\x1b[0m"

#endif // SIMCACHE_TCOLORS_H